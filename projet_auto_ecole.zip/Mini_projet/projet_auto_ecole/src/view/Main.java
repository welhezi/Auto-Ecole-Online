package view;

import exceptions.*;
import models.*;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws NotDispoException1, NotDispoException2, cinException,NotDispoException3 {

        try (Scanner sc=new Scanner(System.in)){
            System.out.println("-------------------------------------*_MENU_*-----------------------------------------");
            System.out.println("**************************************************************************************\n");
            System.out.println("merci de saisir un choix ! \n"+"	1- gestion des condidats\n"+"	2- gestion des vehicules \n "
                    +"	3- gestion des ingenieurs\n"+"	4-gestion des seances\n"+"	5-quitter\n");
            int choix=sc.nextInt();
            Condidat[] co=new Condidat[100];
            Condidats list = new Condidats(100,co);
            Ingenieur[] ingenieurs=new Ingenieur[100];
            Ingenieurs ing=new Ingenieurs(100,ingenieurs);
            Type_permis[] v1=new Type_permis[100];
            Flotte_auto_ecole lis = new Flotte_auto_ecole(100,v1);
            SeancesCondidat[] ss=new SeancesCondidat[100];
            Seances sss=new Seances(100,ss);
            switch(choix) {
                case 1:{ gestion_des_condidats(list,sss);}
                case 2:{ gestion_des_vehicules(lis);}
                case 3:{ gestion_des_ingenieurs(ing,sss);}
                case 4:{ gestion_des_seances(sss,list);}
                default:break;}
        }}


    static void gestion_des_condidats(Condidats list, Seances sss) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    {
        System.out.println("---------------------------|__GESTION DES CONDIDATS__|----------------------------");
        System.out.println("__________________________________________________________________________________\n");
        int again=0;Scanner sc=new Scanner(System.in);
        System.out.println("donner le nombre de condidats ");
        int nb=sc.nextInt();list.setNbCondidats(nb);
        while(again==0)
        {Scanner sc1=new Scanner(System.in);
            System.out.println("merci de saisir un choix ! \n"+"          1-ajouter\n"+"          2-modifier\n"+"          3-supprimer\n"+"          4-rechercher\n"+"          5-afficher\n"+"          6-retourner\n");
            int choix=sc1.nextInt();
            switch(choix) {
                case 1:	{ ajouter_condidats(list,sss);break;}
                case 2: {  modifier_condidat(list,sss);break;}
                case 3:{ supprimer_condidat(list);break;}
                case 4:{ recherche_condidat(list);break;}
                case 5:{list.afficher_condidats();
                    for(int i=0;i<list.getNbCondidats();i++)
                    { Condidat co1=list.getListeCondidats()[i];list.getListeCondidats()[i].getSeances().prix_seances_a_payer(co1);
                        list.getListeCondidats()[i].getSeances().prix_seances_reste_a_payer(co1);}break;}
                default:{again=1;break;}} System.out.println("\n");}
    }

    static void ajouter_condidats(Condidats list, Seances sss) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    {
        for(int i=0;i<list.getNbCondidats();i++)
        { Condidat c=saisie_condidat(sss);list.getListeCondidats()[i]=c;}
    }

    static Condidat saisie_condidat(Seances sss) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    {	Scanner sc=new Scanner(System.in);
        System.out.println("------------------------------------------ donner les parametres de condidat :");
        System.out.println("num_cin : ");
        int num_cin=sc.nextInt();
        String permis=saisie_type_permis();
        Vehicule v=saisie_vehicule(permis);
        SeancesCondidat s=saisie_seancesCondidat(permis,sss);
        Condidat c=new Condidat(num_cin,v,s);
        return c;
    }

    static String saisie_type_permis()
    {Scanner sc=new Scanner(System.in);
        System.out.println("categorie_permis ( A:moto , B:voiture , C:camion ) : ");
        String permis=sc.nextLine();return permis;
    }

    static Vehicule saisie_vehicule(String permis)
    {
        Vehicule v;
        if(permis=="A")   {v=new A("moto");return v;}
        else if(permis=="B")  {v=new B("voiture");return v;}
        else {v=new C("camion");return v;}
    }

    static SeancesCondidat saisie_seancesCondidat(String permis, Seances sss) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    {Scanner sc=new Scanner(System.in);
        System.out.println("nb_seances que vous voulez planifier ? ");
        int nb=sc.nextInt();
        Seance[] seances=new Seance[nb];
        SeancesCondidat s=new SeancesCondidat(nb,seances);
        for(int i=0;i<nb;i++)
        {Seance se=saisie_parametres_seance(permis, sss);
            seances[i]=se;}
        for(int i=0;i<nb;i++)
        {  s.ajouter_seance(seances[i]);} return s;

    }

    static Seance saisie_parametres_seance(String permis, Seances sss) throws NotDispoException2, NotDispoException3, NotDispoException1
    { Scanner sc=new Scanner(System.in);
        System.out.println("------------------------------------------ donner les parametres de seance :");
        System.out.println("1-seance_code / 2-seance_conduite / 3-examen");
        int seance=sc.nextInt();
        if(seance==1) {Seance_code s = null;
            try {s = saisie_parametres_seance_code();} catch (cinException e) {e.getMessage();}return s;}
        else if(seance==2){Seance_conduite s1=saisie_parametres_seance_conduite(permis,sss);return s1;}
        else {Examen s2 = null;
            try {s2 = saisie_parametres_Examen();} catch (cinException e) {e.getMessage();}return s2;}
    }

    static Seance_code saisie_parametres_seance_code() throws cinException
    {Scanner sc=new Scanner(System.in);
        System.out.println("num_seance : ");
        int num_seance=sc.nextInt();
        Date d=saisie_date();
        System.out.println("heure : ");
        int heure=sc.nextInt();
        Ingenieur ing=saisie_parametres_ingenieur();
        Seance_code s=new Seance_code(num_seance,d,heure,ing);
        return s;
    }

    static Seance_conduite saisie_parametres_seance_conduite(String permis, Seances sss) throws NotDispoException2, NotDispoException3, NotDispoException1
    {Scanner sc=new Scanner(System.in);	Seance_conduite s = null;
        System.out.println("num_seance : ");
        int num_seance=sc.nextInt();
        Date d=saisie_date();
        System.out.println("heure : ");
        int heure=sc.nextInt();
        Ingenieur ing = null;
        try { ing = saisie_parametres_ingenieur();
        } catch (cinException e1) {e1.getMessage();}
        Type_permis v=saisie_parametres_vehicule(permis);
        int t=dispo_ingenieur_vehicule(sss,ing,v, heure,d);
        if(t==1) {try {s = new Seance_conduite(num_seance,d,heure,ing,v);} catch (NotDispoException1 e) {e.getMessage();}}
        else if(t==2) {try {s = new Seance_conduite(num_seance,d,heure,ing,v);} catch (NotDispoException2 e) {e.getMessage();}}
        else if(t==3) {try {s = new Seance_conduite(num_seance,d,heure,ing,v);} catch (NotDispoException3 e) {e.getMessage();}}
        else {s = new Seance_conduite(num_seance,d,heure,ing,v);}
        return s;
    }


    static int dispo_ingenieur_vehicule(Seances sss,Ingenieur g,Type_permis v,int heure,Date d)
    {int t;
        if(g.dispo_ingenieur(sss,g,heure,d)==true && v.dispo_vehicule(sss,v,heure,d)==false)
            t=1;
        else if(g.dispo_ingenieur(sss,g,heure, d)==false && v.dispo_vehicule(sss,v,heure,d)==true)
            t=2;
        else if(g.dispo_ingenieur(sss,g,heure, d)==false && v.dispo_vehicule(sss,v,heure,d)==false)
            t=3;
        else t=4;
        return t;

    }

    static Examen saisie_parametres_Examen() throws cinException
    {Scanner sc=new Scanner(System.in);
        System.out.println("num_seance : ");
        int num_seance=sc.nextInt();
        Date d=saisie_date();
        System.out.println("heure : ");
        int heure=sc.nextInt();
        Ingenieur ing=saisie_parametres_ingenieur();
        Examen e=new Examen(num_seance,d,heure,ing);
        return e;
    }

    static Ingenieur saisie_parametres_ingenieur() throws cinException
    { Scanner sc=new Scanner(System.in);
        System.out.println("------------------------------------------ donner les parametres d'ingenieur :");
        System.out.println("num_cin : ");
        int num=sc.nextInt();
        sc.nextLine();
        System.out.println("nom : ");
        String nom=sc.nextLine();
        Scanner sc2=new Scanner(System.in);
        System.out.println("prenom : ");
        String prenom=sc2.nextLine();
        Ingenieur ing=new Ingenieur(num,nom,prenom);
        return ing;
    }







    static Type_permis saisie_parametres_vehicule(String permis)
    { Scanner sc=new Scanner(System.in);
        System.out.println("------------------------------------------ donner les parametres de vehicule :");
        System.out.println("num_immatriculation : ");
        int num=sc.nextInt();
        System.out.println("date_mise_en_service : ");
        Date d=saisie_date();
        System.out.println("kilometrage_total : ");
        int k=sc.nextInt();
        Type_permis v;
        if(permis=="A") v=new Moto(num,d,k,0);
        else if(permis=="B") v=new Voiture(num,d,k,0);
        else v=new Camion(num,d,k,0);
        Type_permis[] v1=new Type_permis[10];
        Flotte_auto_ecole listeV = new Flotte_auto_ecole(100,v1);
        listeV.ajouter_vehicule(v);
        return v;}


    static void supprimer_condidat(Condidats list) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    {	int complet=0;
        for(int i=0;i<list.getNbCondidats();i++)
        {if(list.getListeCondidats()[i]==null) complet=1;}
        if(complet==1)
        {System.out.println("le tableau est vide ");}
        else {
            Scanner sc=new Scanner(System.in);
            System.out.println("donner le cin de condidat dont on va faire la suppression ");
            int cin=sc.nextInt();
            for(int i=0;i<list.getNbCondidats();i++)
            { if(list.getListeCondidats()[i].getNum_cin()==cin)
            { list.supprimer_condidat(list.getListeCondidats()[i]);break;}
            }}
    }

    static void recherche_condidat(Condidats list)
    {	int complet=0;
        for(int i=0;i<list.getNbCondidats();i++)
        {if(list.getListeCondidats()[i]==null) complet=1;}
        if(complet==1)
        {System.out.println("le tableau est vide ");}
        else {
            Scanner sc=new Scanner(System.in);
            System.out.println("donner le cin de condidat dont on va faire la recherche ");
            int cin=sc.nextInt();
            Condidat c1=list.rechercher_condidat(cin);c1.afficher_condidat();}
    }

    static void modifier_condidat(Condidats list, Seances sss) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    {	int complet=0;
        for(int i=0;i<list.getNbCondidats();i++)
        {if(list.getListeCondidats()[i]==null) complet=1;}
        if(complet==1)
        {System.out.println("le tableau est vide ");}
        else {
            Scanner sc=new Scanner(System.in);
            System.out.println("donner le cin de condidat dont on va faire la modification ");
            int cin=sc.nextInt();
            for(int i=0;i<list.getNbCondidats();i++)
            { if(list.getListeCondidats()[i].getNum_cin()==cin)
            { int again=0;while(again==0)
            {System.out.println("donner le parametre a modifier\n"+"          1-num_cin\n"+"          2-type_permis\n"+"          3-seances_Condidat\n"+"          4-retour\n");
                int choix=sc.nextInt();
                if(choix==1) {			System.out.println("donner le nouveau parametre\n");int cin1=sc.nextInt();
                    list.getListeCondidats()[i].modifier_num_cin(list.getListeCondidats()[i], cin1);break;}
                else if(choix==2) {		String permis=saisie_type_permis();
                    Vehicule v=saisie_vehicule(permis);
                    list.getListeCondidats()[i].modifier_permis(list.getListeCondidats()[i], v);break;}
                else if(choix==3) {		String permis=saisie_type_permis();
                    SeancesCondidat s=saisie_seancesCondidat(permis,sss);
                    list.getListeCondidats()[i].modifier_seances(list.getListeCondidats()[i], s);break;}
                else {again=1;break;}
            }System.out.println("\n");}
            else {System.out.println("le condidat n'existe pas");}
            }}
    }








    static Date saisie_date()
    {	Scanner sc=new Scanner(System.in);
        System.out.println("date (annee,mois,jour) : ");
        System.out.println("annee= ");
        int annee=sc.nextInt();
        System.out.println("mois= ");
        int mois=sc.nextInt();
        System.out.println("jour= ");
        int jour=sc.nextInt();
        Date d=new Date(annee,mois,jour);
        return d;
    }




    static void gestion_des_ingenieurs(Ingenieurs ing, Seances sss) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    {	Scanner sc=new Scanner(System.in);
        System.out.println("---------------------------|__GESTION DES INGENIEURS__|----------------------------");
        System.out.println("___________________________________________________________________________________\n");
        int again=0;System.out.println("donner le nombre d'ingenieurs ");
        int nb=sc.nextInt();ing.setNbIngenieurs(nb);
        while(again==0)
        {System.out.println("merci de saisir un choix ! \n"+"          1-ajouter\n"+"          2-modifier\n"+"          3-supprimer\n"+"          4-rechercher"+"          5-afficher\n"+"          6-retourner\n");
            int choix1=sc.nextInt();
            switch(choix1) {
                case 1:	{ ajouter_ingenieurs(ing);break;}
                case 2: { modifier_ingenieur(ing);break;}
                case 3:{ supprimer_ingenieur(ing);break;}
                case 4:{recherche_ingenieur(ing);break;}
                case 5:{ing.afficher_Ingenieur();ing.salaire_ingenieurs(sss);break;}
                default:{again=1;break;}
            }System.out.println("\n");}}

    static void ajouter_ingenieurs(Ingenieurs ing) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    { Scanner sc=new Scanner(System.in);
        for(int i=0;i<ing.getNbIngenieurs();i++)
        { Ingenieur in=saisie_parametres_ingenieur();ing.getListeIngenieurs()[i]=in;}
    }

    static void modifier_ingenieur(Ingenieurs list) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    { int complet=0;
        for(int i=0;i<list.getNbIngenieurs();i++)
        {if(list.getListeIngenieurs()[i]==null) complet=1;}
        if(complet==1)
        {System.out.println("le tableau est vide ");}
        else
        {Scanner sc=new Scanner(System.in);
            System.out.println("donner le num_cin d'ingenieur dont on va faire la modification ");
            int cin=sc.nextInt();
            for(int i=0;i<list.getNbIngenieurs();i++)
            { if(list.getListeIngenieurs()[i].getCin()==cin)
            {	int again=0;while(again==0)
            {System.out.println("donner le parametre a modifier\n"+"          1-num_cin\n"+"          2-nom\n"+"          3-prenom\n"+"          4-retour\n");
                int choix=sc.nextInt();
                if(choix==1) {	System.out.println("donner le nouveau parametre\n");int cin1=sc.nextInt();
                    for(int j=0;i<list.getNbIngenieurs();j++)
                    {if(list.getListeIngenieurs()[j].getCin()==cin)
                    {list.getListeIngenieurs()[j].modifier_cin(cin1);break;}}
                }
                else if(choix==2) {	System.out.println("donner le nouveau parametre\n");String nom=sc.nextLine();
                    for(int j=0;i<list.getNbIngenieurs();j++)
                    {if(list.getListeIngenieurs()[j].getCin()==cin)
                    {list.getListeIngenieurs()[j].modifier_nom(nom);break;}}
                }
                else if(choix==3) {	System.out.println("donner le nouveau parametre\n");String prenom=sc.nextLine();
                    for(int j=0;i<list.getNbIngenieurs();j++)
                    {if(list.getListeIngenieurs()[j].getCin()==cin)
                    {list.getListeIngenieurs()[j].modifier_prenom(prenom);break;}}
                }
                else {again=1;break;}
            }System.out.println("\n");}
            else {System.out.println("vehicule n'existe pas");}
            }}
    }

    private static void recherche_ingenieur(Ingenieurs list) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3 {
        int complet=0;
        for(int i=0;i<list.getNbIngenieurs();i++)
        {if(list.getListeIngenieurs()[i]==null) complet=1;}
        if(complet==1)
        {System.out.println("le tableau est vide ");}
        else {
            Scanner sc=new Scanner(System.in);
            System.out.println("donner le num_cin d'ingenieur dont on va faire la recherche ");
            int cin=sc.nextInt();
            for(int i=0;i<list.getNbIngenieurs();i++)
            { if(list.getListeIngenieurs()[i].getCin()==cin)
            { Ingenieur g=list.rechercher_Ingenieur(list.getListeIngenieurs()[i]);g.afficher();break;}
            }}

    }

    static void supprimer_ingenieur(Ingenieurs list) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3 {
        int complet=0;
        for(int i=0;i<list.getNbIngenieurs();i++)
        {if(list.getListeIngenieurs()[i]==null) complet=1;}
        if(complet==1)
        {System.out.println("le tableau est vide ");}
        else {
            Scanner sc=new Scanner(System.in);
            System.out.println("donner le num_cin d'ingenieur dont on va faire la suppression ");
            int cin=sc.nextInt();
            for(int i=0;i<list.getNbIngenieurs();i++)
            { if(list.getListeIngenieurs()[i].getCin()==cin)
            { list.supprimer_Ingenieur(list.getListeIngenieurs()[i]);break;}
            }}

    }















    static void gestion_des_vehicules(Flotte_auto_ecole list) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    {	Scanner sc=new Scanner(System.in);
        System.out.println("----------------------------|__GESTION DES VEHICULES__|----------------------------");
        System.out.println("___________________________________________________________________________________\n");
        int again=0;
        System.out.println("donner le nombre de vehicules ");
        int nb=sc.nextInt();list.setNb_vehicules(nb);
        while(again==0) {
            System.out.println("merci de saisir un choix ! \n"+"          1-ajouter\n"+"          2-modifier\n"+"          3-supprimer\n"+"          4-rechercher"+"          5-afficher\n"+"          6-rapport sur l'etat des vehicules\n"+"          7-retourner\n");
            int choix1=sc.nextInt();
            switch(choix1) {
                case 1:	{ ajouter_vehicules(list);break;}
                case 2: { modifier_vehicule(list);break;}
                case 3:{ supprimer_vehicule(list);break;}
                case 4:{ recherche_vehicule(list);break;}
                case 5:{list.afficher_vehicules();break;}
                case 6:{list.tester_etat_voitures();break;}
                default:{again=1;break;}
            }System.out.println("\n");}}

    static void ajouter_vehicules(Flotte_auto_ecole list) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    { for(int i=0;i<list.getNb_vehicules();i++)
    { String permis=saisie_type_permis();Type_permis v=saisie_parametres_vehicule(permis);list.getVehicules()[i]=v;}
        for(int i=0;i<list.getNb_vehicules();i++)
        {  list.ajouter_vehicule(list.getVehicules()[i]);} }

    static void modifier_vehicule(Flotte_auto_ecole listv) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    { int complet=0;
        for(int i=0;i<listv.getNb_vehicules();i++)
        {if(listv.getVehicules()[i]==null) complet=1;}
        if(complet==1)
        {System.out.println("le tableau est vide ");}
        else
        {Scanner sc=new Scanner(System.in);
            System.out.println("donner le num_immatriculation de vehicule dont on va faire la modification ");
            int cin=sc.nextInt();
            for(int i=0;i<listv.getNb_vehicules();i++)
            { if(listv.getVehicules()[i].getNum_immatriculation()==cin)
            { int again=0;while(again==0)
            {System.out.println("donner le parametre a modifier\n"+"          1-num_immatriculation\n"+"          2-date_mise_service\n"+"          3-kilometrage_total\n"+"          4-nb_km_restant_prochainEntretient\n"+"          5-retour\n");
                int choix=sc.nextInt();
                if(choix==1) {			System.out.println("donner le nouveau parametre\n");int cin1=sc.nextInt();
                    for(int j=0;j<listv.getNb_vehicules();j++)
                    {if(listv.getVehicules()[j].getNum_immatriculation()==cin)
                    {listv.getVehicules()[j].modifier_num_immatriculation(cin1);break;}}
                }
                else if(choix==2) {		Date d=saisie_date();
                    listv.getVehicules()[i].modifier_date_mise_service(d);break;}
                else if(choix==3) {		System.out.println("donner le nouveau parametre\n");int cin1=sc.nextInt();
                    for(int j=0;j<listv.getNb_vehicules();j++)
                    {if(listv.getVehicules()[j].getNum_immatriculation()==cin)
                    {listv.getVehicules()[j].modifier_kilometrage_total(cin1);break;}}
                }
                else if(choix==4) {		System.out.println("donner le nouveau parametre\n");int cin1=sc.nextInt();
                    for(int j=0;j<listv.getNb_vehicules();j++)
                    {if(listv.getVehicules()[j].getNum_immatriculation()==cin)
                    {listv.getVehicules()[j].modifier_nb_km_restant_prochainEntretient(cin1);break;}}}
                else {again=1;break;}System.out.println("\n");}}
            else {System.out.println("vehicule n'existe pas");}
            }}}

    static void supprimer_vehicule(Flotte_auto_ecole listev) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    {int complet=0;
        for(int i=0;i<listev.getNb_vehicules();i++)
        {if(listev.getVehicules()[i]==null) complet=1;}
        if(complet==1)
        {System.out.println("le tableau est vide ");}
        else
        {Scanner sc=new Scanner(System.in);
            System.out.println("donner le num_immatriculation de vehicule dont on va faire la suppression ");
            int cin=sc.nextInt();
            for(int i=0;i<listev.getNb_vehicules();i++)
            { if(listev.getVehicules()[i].getNum_immatriculation()==cin)
            { listev.supprimer_vehicule(listev.getVehicules()[i]);break;}
            }}}

    static void recherche_vehicule(Flotte_auto_ecole listev) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    {int complet=0;
        for(int i=0;i<listev.getNb_vehicules();i++)
        {if(listev.getVehicules()[i]==null) complet=1;}
        if(complet==1)
        {System.out.println("le tableau est vide ");}
        else
        {Scanner sc=new Scanner(System.in);
            System.out.println("donner le num_immatriculation de vehicule dont on va faire la recherche ");
            int cin=sc.nextInt();
            for(int i=0;i<listev.getNb_vehicules();i++)
            { if(listev.getVehicules()[i].getNum_immatriculation()==cin)
            { Type_permis v=listev.rechercher_vehicule(listev.getVehicules()[i]);v.afficher();break;}
            }}}





    static void gestion_des_seances(Seances sss, Condidats list) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3
    {
        System.out.println("----------------------------|__GESTION DES SEANCES__|-----------------------------");
        System.out.println("__________________________________________________________________________________\n");
        int again=0;Scanner sc=new Scanner(System.in);
        System.out.println("nb_seances que vous voulez planifier ? ");
        int nb=sc.nextInt();sss.setN(nb);
        while(again==0)
        {Scanner sc1=new Scanner(System.in);
            System.out.println("merci de saisir un choix ! \n"+"          1-ajouter\n"+"          2-modifier\n"+"          3-supprimer\n"+"          4-rechercher\n"+"          5-afficher\n"+"          6-retourner\n");
            int choix=sc1.nextInt();
            switch(choix) {
                case 1:	{ ajouter_seances(sss);break;}
                case 2: {  modifier_seance(sss);break;}
                case 3:{ supprimer_seance(sss);break;}
                case 4:{ recherche_seance(sss);break;}
                case 5:{sss.afficher();break;}
                default:{again=1;break;}} System.out.println("\n");}
    }


    private static void recherche_seance(Seances sss)
    {int complet=0;
        for(int i=0;i<sss.getN();i++)
        {if(sss.getS()[i]==null) complet=1;}
        if(complet==1)
        {System.out.println("le tableau est vide ");}
        else
        {Scanner sc=new Scanner(System.in);
            System.out.println("donner le num_seance dont on va faire la recherche ");
            int cin=sc.nextInt();
            for(int i=0;i<sss.getN();i++)
            { if(sss.getS()[i].getListeSeances()[i].getNum_seance()==cin)
            { Seance s=sss.getS()[i].rechercher_seance(sss.getS()[i].getListeSeances()[i]);s.afficher();break;}
            }}}


    private static void supprimer_seance(Seances sss) {
        {int complet=0;
            for(int i=0;i<sss.getN();i++)
            {if(sss.getS()[i]==null) complet=1;}
            if(complet==1)
            {System.out.println("le tableau est vide ");}
            else
            {Scanner sc=new Scanner(System.in);
                System.out.println("donner le num_seance dont on va faire la suppression ");
                int cin=sc.nextInt();
                for(int i=0;i<sss.getN();i++)
                { if(sss.getS()[i].getListeSeances()[i].getNum_seance()==cin)
                { sss.getS()[i].supprimer_seance(sss.getS()[i].getListeSeances()[i]);break;}
                }}}
    }


    static void modifier_seance(Seances sss) throws cinException
    {  int complet=0;
        for(int i=0;i<sss.getN();i++) {if(sss.getS()[i]==null) complet=1;}
        if(complet==1) {System.out.println("le tableau est vide ");}
        else {
            Scanner sc=new Scanner(System.in);
            System.out.println("donner le num_seance dont on va faire la modification ");
            int cin=sc.nextInt();
            for(int i=0;i<sss.getN();i++)
            { if(sss.getS()[i].getListeSeances()[i].getNum_seance()==cin) {

                if(sss.getS()[i].getListeSeances()[i] instanceof Seance_code ||sss.getS()[i].getListeSeances()[i] instanceof Examen)
                { int again=0;while(again==0)
                {System.out.println("donner le parametre a modifier\n"+"          1-num_seance\n"+"          2-date_seance\n"+"          3-ingenieur\n"+"          4-heure\n"+"          5-retour\n");
                    int choix=sc.nextInt();
                    if(choix==1) {System.out.println("donner le nouveau parametre\n");int cin1=sc.nextInt();sss.getS()[i].getListeSeances()[i].modifier_num_seance(cin1);break;}
                    else if(choix==2) {	Date d=saisie_date();sss.getS()[i].getListeSeances()[i].modifier_date_seance(d);break;}
                    else if(choix==3) {	Ingenieur g=saisie_parametres_ingenieur();sss.getS()[i].getListeSeances()[i].modifier_ingenieur(g);break;}
                    else if(choix==4) {System.out.println("donner le nouveau parametre\n");int cin2=sc.nextInt();sss.getS()[i].getListeSeances()[i].modifier_heure(cin2);break;}
                    else {again=1;break;}}}

                else //(sss.getS()[i].getListeSeances()[i] instanceof Seance_conduite )
                { int again=0;while(again==0)
                { System.out.println("donner le parametre a modifier\n"+"          1-num_seance\n"+"          2-date_seance\n"+"          3-ingenieur\n"+"          4-heure\n"+"          5-vehicule\n"+"          6-retour\n");
                    int choix=sc.nextInt();
                    if(choix==1) {System.out.println("donner le nouveau parametre\n");int cin1=sc.nextInt();sss.getS()[i].getListeSeances()[i].modifier_num_seance(cin1);break;}
                    else if(choix==2) {	Date d=saisie_date();sss.getS()[i].getListeSeances()[i].modifier_date_seance(d);break;}
                    else if(choix==3) {	Ingenieur g=saisie_parametres_ingenieur();sss.getS()[i].getListeSeances()[i].modifier_ingenieur(g);break;}
                    else if(choix==4) {System.out.println("donner le nouveau parametre\n");int cin2=sc.nextInt();sss.getS()[i].getListeSeances()[i].modifier_heure(cin2);break;}
                    else if(choix==5) { String permis=saisie_type_permis();Type_permis v=saisie_parametres_vehicule(permis);((Seance_conduite)sss.getS()[i].getListeSeances()[i]).modifier_voiture(v);break;}
                    else {again=1;break;}}}
            }
            else {System.out.println("seance n'existe pas");}
            }
        }}



    static void ajouter_seances(Seances sss) throws cinException, NotDispoException1, NotDispoException2, NotDispoException3 {
        String permis=saisie_type_permis();
        SeancesCondidat ss=saisie_seancesCondidat(permis,sss);
        for(int i=0;i<sss.getN();i++)
        {sss.getS()[i]=ss;}
    }







}