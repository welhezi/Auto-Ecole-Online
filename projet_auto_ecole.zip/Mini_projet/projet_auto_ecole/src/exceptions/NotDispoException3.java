package exceptions;

public class NotDispoException3 extends Exception {

	public NotDispoException3() {
		super("vehicule et ingenieur doivent etre disponibles");
		
	}

	public NotDispoException3(String message) {
		super(message);
	}

	
}
