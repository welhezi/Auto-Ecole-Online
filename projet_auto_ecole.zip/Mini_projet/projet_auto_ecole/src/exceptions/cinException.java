package exceptions;

public class cinException extends Exception{
	
	public cinException() {
		super("le numero carte d'identite doit etre de taille 8 ");
	}

	public cinException(String message) {
		super(message);
	}

}
