package exceptions;

public class NotDispoException2 extends Exception{
	
	public NotDispoException2(String message) {
		super(message);
		}

	public NotDispoException2() {
		super("vehicule n'est pas disponible");
	}
}
