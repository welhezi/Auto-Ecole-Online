package exceptions;

public class NotDispoException1 extends Exception {

	public NotDispoException1(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NotDispoException1() {
		super("l'ingenieur doit etre disponible ");
	}
	

}
