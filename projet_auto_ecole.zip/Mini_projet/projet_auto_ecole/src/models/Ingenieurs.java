package models;

public class Ingenieurs {
/******************************************************************* les attributs  ****************************************************************************************/

	private int nbIngenieurs;
	private Ingenieur[] listeIngenieurs=new Ingenieur[nbIngenieurs];
/******************************************************************* le constructeur  **************************************************************************************/
	public Ingenieurs(int nbIngenieurs, Ingenieur[] listeIngenieurs) {
		super();
		this.nbIngenieurs = nbIngenieurs;
		this.listeIngenieurs = listeIngenieurs;
	}
/******************************************************************* setter et getter ***********************************************************************************/
	

	public int getNbIngenieurs() {
	return nbIngenieurs;
}


public void setNbIngenieurs(int nbIngenieurs) {
	this.nbIngenieurs = nbIngenieurs;
}


public Ingenieur[] getListeIngenieurs() {
	return listeIngenieurs;
}


public void setListeIngenieurs(Ingenieur[] listeIngenieurs) {
	this.listeIngenieurs = listeIngenieurs;
}


	/******************************************************************* les m�thodes *****************************************************************************************/
	public void ajouter_ingenieur (Ingenieur c){
		
		boolean trouve = false;
		
		for (int i = 0; i < this.listeIngenieurs.length; i++) {
			if (this.listeIngenieurs[i] == null) {
				trouve = true;
			}
		}
		
		if (trouve) {
			
			Ingenieur x0 = null;
			
			for (int i = 0; i < this.listeIngenieurs.length; i++) {
				if (this.listeIngenieurs[i] != null) {
					if (this.listeIngenieurs[i].equals(c)) {
						x0 = this.listeIngenieurs[i];
					}
				}
			}
			
			if (x0 == null) {
				for (int i = 0; i < this.listeIngenieurs.length; i++) {
					if (this.listeIngenieurs[i] == null) {
						this.listeIngenieurs[i] = c;
						System.out.println("Ingenieur est ajoute avec succe");
						break;
					}
				}
			}
			else
				System.out.println("Ingenieur existe deja ");
		}
	}


	public Ingenieur rechercher_Ingenieur(Ingenieur s){
		
		for (int i = 0; i < this.listeIngenieurs.length; i++) {
			if (this.listeIngenieurs[i] != null) {
				if (this.listeIngenieurs[i].equals(s) == true ) {
					return this.listeIngenieurs[i];
				}
			}
		}
		System.out.println("l'Ingenieur n'existe pas !");
		return null;
	}

	public void supprimer_Ingenieur(Ingenieur c)
	{ int pos=0;
		if(rechercher_Ingenieur(c) != null)
		{	
			for (int i = 0; i < this.listeIngenieurs.length; i++)
			{
				if(this.listeIngenieurs[i].equals(c) )
					pos=i;
			}
			for (int i = pos; i < this.getNbIngenieurs()-1; i++)
			{ this.listeIngenieurs[i] = this.listeIngenieurs[i+1];}
		 
		 }	
		else 
			System.out.println("Ingenieur n'existe pas !");
		}

	public void afficher_Ingenieur() 
	{	
	  for(int i=0;i<this.getNbIngenieurs();i++)
	     { System.out.println("-----------------------------------------------------_______ Ingenieur num " +i+ " _________--------\n");
	     this.listeIngenieurs[i].afficher();
	     }
	}

	public void modifier_Ingenieur(Ingenieur v1,Ingenieur v2)
	{
		for(int i=0;i<this.getNbIngenieurs();i++)
		{
			if(v1.equals(v2)==true)
				System.out.println("Ingenieur existe");
			else {if(this.listeIngenieurs[i].equals(v1))
				this.listeIngenieurs[i]=v2;break;
			}
		}
	}
	
	public void salaire_ingenieurs(Seances s)
	{  
		for(int i=0;i<this.getNbIngenieurs();i++)
		{s.salaire_ingenieur(this.listeIngenieurs[i]);}
	}
	
	
/*	public int ingenieur_disponible_ingenieurs(Seances s,int h,Date d)
	{int pos=-1;boolean b;
		for(int i=0;i<this.getNbIngenieurs();i++)
		{
			b=s.disponibilite_ingenieur_seances(this.listeIngenieurs[i], h, d);
			if(b==true) {pos=i;break;}
			else
				System.out.println("merci de saisir une autre heure ou date ");
		}
		return pos;		
	}
	*/
	
	
	
	
	
	
	
	
}
