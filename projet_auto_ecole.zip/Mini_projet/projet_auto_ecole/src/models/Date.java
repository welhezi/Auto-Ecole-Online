package models;

public class Date {
/******************************************************************* les attributs  ****************************************************************************************/
private int annee;
private int mois;
private int jour;
/******************************************************************* le constructeur  **************************************************************************************/
public Date(int annee, int mois, int jour) {
	super();
	this.annee = annee;
	this.mois = mois;
	this.jour = jour;
}
/*********************************************************************** m�thodes ***************************************************************************************/
public void afficher() {
	System.out.println(getAnnee()+"/"+ getMois() + "/" + getJour() );
}

/******************************************************************* setter et getter ***********************************************************************************/
public int getAnnee() {
	return annee;
}
public void setAnnee(int annee) {
	this.annee = annee;
}

public int getMois() {
	return mois;
}

public void setMois(int mois) {
	this.mois = mois;
}

public int getJour() {
	return jour;
}

public void setJour(int jour) {
	this.jour = jour;
}




}
