package models;

import exceptions.cinException;

public class Condidat {
/******************************************************************* les attributs  ****************************************************************************************/
     private int num_cin;
     private Vehicule categorie_permis;
     private Seance[] lists=new Seance[100];
     private SeancesCondidat seances=new SeancesCondidat(100,lists);
/******************************************************************* le constructeur  **************************************************************************************/
public Condidat(int num_cin, Vehicule categorie_permis,SeancesCondidat seances) throws cinException
{  if(longeur(num_cin)!=8) throw new cinException();
    this.num_cin = num_cin;
	this.categorie_permis = categorie_permis;
	this.seances=seances;
}

/******************************************************************* les m�thodes *****************************************************************************************/
public int longeur(int i)
{ String ch=String.valueOf(i);
 return ch.length();}
public void afficher_condidat() 
{	
System.out.println("Condidat [num_cin=" + getNum_cin()+ ",  categorie_permis :");
 getCategorie_permis().afficher();
System.out.println(" seances :");
seances.afficher_seances();
System.out.println("]"); 
}
public void modifier_num_cin(Condidat c,int num)
{ if(c.getNum_cin()==num)
	System.out.println("on ne peut pas modifier car le num_cin existe deja");
else 
{ c.setNum_cin(num);
System.out.println("modification de num_cin termine");
}}

public void modifier_permis(Condidat c,Vehicule p)
{ if(c.getCategorie_permis()==p)
	System.out.println("on ne peut pas modifier car le type de permis existe deja");
else 
{ c.setCategorie_permis(p);
System.out.println("modification de permis termine");
}}

public void modifier_seances(Condidat c,SeancesCondidat s)
{ if(c.getSeances()==s)
	System.out.println("on ne peut pas modifier car les seances existe deja");
else 
{ c.setSeances(s);
System.out.println("modification de permis termine");
}}
public float calcul_prix_seance_condidat(Condidat c,Seance s) {
	float p=0;
	p=s.calcul_prix_seance(c,s);
return p;
	}	



/******************************************************************* setter et getter ***********************************************************************************/
public int getNum_cin() {
	return num_cin;
}
public void setNum_cin(int num_cin) {
	this.num_cin = num_cin;
}
public Vehicule getCategorie_permis() {
	return categorie_permis;
}
public void setCategorie_permis(Vehicule categorie_permis) {
	this.categorie_permis = categorie_permis;
}

public SeancesCondidat getSeances() {
	return seances;
}
public void setSeances(SeancesCondidat seances) {
	this.seances = seances;
}




}
