package models;

import exceptions.cinException;

public class Ingenieur {
/******************************************************************* les attributs  ****************************************************************************************/
private String nom;
private String prenom;
private int cin;
private Seances s;
/******************************************************************* le constructeur  **************************************************************************************/
public Ingenieur(int cin,String nom,String prenom) throws cinException
{  if(longeur(cin)!=8) throw new cinException();
	this.cin=cin;
	this.prenom=prenom;
	this.nom = nom;
}
/******************************************************************* les m�thodes *****************************************************************************************/

public void ajouter_Ingenieur(Seance tab[],Ingenieur c)
{ System.out.println("ajout d'Ingenieur avec succe ");}

public void afficher() {
	System.out.println("ingenieur [cin= "+this.getCin()+",Nom= "+ this.getNom()+" ,prenom= "+this.getPrenom()+"]"); 
}

public void modifier_cin(int a)
{this.setCin(a);}

public void modifier_nom(String a)
{this.setNom(a);}

public void modifier_prenom(String a)
{this.setPrenom(a);}


public int payer_ingenieur(Seance s)
{ int p=0;
	if(s instanceof Seance_code)
		p=7000;
	else if(s instanceof Seance_conduite)
		p=10000;	
	return p;}

public int longeur(int i)
{ String ch=String.valueOf(i);
 return ch.length();}


public boolean dispo_ingenieur(Seances sss,Ingenieur g,int h,Date d)
{ boolean dispo,res;
dispo=sss.disponibilite_ingenieur_seances(g, h, d);
if(dispo==true) 
	res=true;
else
	res=false;
return res;
}











/******************************************************************* setter et getter ***********************************************************************************/
public String getNom() {
	return nom;
}
public String getPrenom() {
	return prenom;
}
public void setNom(String nom) {
	this.nom = nom;
}
public void setPrenom(String prenom) {
	this.prenom = prenom;
}
public Seances getS() {
	return s;
}
public void setS(Seances s) {
	this.s = s;
}

public int getCin() {
	return cin;
}
public void setCin(int cin) {
	this.cin = cin;
}


}

/******************************************************************* les attributs  ****************************************************************************************/

/******************************************************************* le constructeur  **************************************************************************************/

/******************************************************************* les m�thodes *****************************************************************************************/

/******************************************************************* setter et getter ***********************************************************************************/

