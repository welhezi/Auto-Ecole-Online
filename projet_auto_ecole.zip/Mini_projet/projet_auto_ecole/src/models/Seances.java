package models;

public class Seances {
private int n;
private SeancesCondidat[] s=new SeancesCondidat[n];
public Seances(int n, SeancesCondidat[] s) {
	super();
	this.n = n;
	this.s = s;
}
public int getN() {
	return n;
}
public void setN(int n) {
	this.n = n;
}
public SeancesCondidat[] getS() {
	return s;
}
public void setS(SeancesCondidat[] s) {
	this.s = s;
}

public void afficher()
{ for(int i=0;i<this.getN();i++)
{ System.out.println("------------------------------------------------------------------------__||**** SEANCES num " +i+ " ****||__--------\n");
this.s[i].afficher_seances();}}

public void salaire_ingenieur(Ingenieur g)
{ int salaire=0,t;
	
for(int i=0;i<this.getN();i++)
	{salaire=salaire+this.s[i].salaire_ingenieur(g);}
t=g.getCin();
System.out.println("salaire de l'ingenieur de cin "+t+" = "+salaire);
}

public boolean disponibilite_ingenieur_seances(Ingenieur g,int h,Date d)
{int dispo=-1;Boolean disponible;
int vide=0;
for(int i=0;i<this.getN();i++)
{if(this.s[i]==null) vide=1;else vide=0;}
if(vide==1) { disponible=true;return disponible;}
else { for(int i=0;i<this.getN();i++)
	{dispo=this.s[i].disponibilite_ingenieur_seancesCondidat(g, h, d);}
	if(dispo==0) 
		disponible=true;
	else 
		disponible=false;
	return disponible;}	
}

public boolean disponibilite_vehicule_seances(Type_permis g,int h,Date d)
{int dispo=-1;Boolean disponible;
int vide=0;
for(int i=0;i<this.getN();i++)
{if(this.s[i]==null) vide=1;else vide=0;}
if(vide==1) { disponible=true;return disponible;}
else { 	
for(int i=0;i<this.getN();i++)
	{dispo=this.s[i].disponibilite_vehicule_seancesCondidat(g,h, d);}
	if(dispo==0) 
		disponible=true;
	else 
		disponible=false;
	return disponible;}	
}


}
