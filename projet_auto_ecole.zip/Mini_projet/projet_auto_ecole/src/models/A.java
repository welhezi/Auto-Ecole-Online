package models;

public class A extends Vehicule {

	public A(String moto) {
		super(moto);
	}
@Override
	public void afficher() {
	System.out.println("permis pour les moto");
}
}
