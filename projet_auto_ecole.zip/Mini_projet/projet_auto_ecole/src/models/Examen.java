package models;

public class Examen extends Seance implements Payant{

	public Examen(int num_seance, Date date_seance, int heure, Ingenieur ingenieur) {
		super(num_seance, date_seance, heure, ingenieur);	
	}
	
	@Override
	public void afficher() {
		System.out.println("examen [Num_seance=" + getNum_seance() + ", Date_seance=");
		getDate_seance().afficher();
		System.out.println(",heure="+getHeure()+" , ingenieur= ");
		getIngenieur().afficher();
		System.out.println("]");
	}
	@Override
	public void ajouter_seance(Examen s)
	{ System.out.println("ajoute d'examen ");
			}
	@Override
	public float calcul_prix(Condidat c) {
		return 50;
	}
	
	

}
