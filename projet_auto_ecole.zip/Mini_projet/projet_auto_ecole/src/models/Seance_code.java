package models;

public class Seance_code extends Seance implements Payant {

/******************************************************************* les attributs  ****************************************************************************************/

/******************************************************************* le constructeur  **************************************************************************************/
public Seance_code(int num_seance, Date date_seance, int heure, Ingenieur ingenieur)
{
		super(num_seance, date_seance, heure, ingenieur);
			
}
/******************************************************************* les m�thodes *****************************************************************************************/
@Override
public float calcul_prix(Condidat c) 
{ float p=15;
	if( c.getCategorie_permis() instanceof A)
	    p=p+(p*2)/100;
    else if(c.getCategorie_permis() instanceof B)
    	p=p+(p*3)/100;
    else
    	p=p+(p*5)/100;
return p;
}
@Override
public void afficher() { 
System.out.println("seance_code [Num_seance=" + getNum_seance() + ", Date_seance=");
getDate_seance().afficher();
System.out.println(",heure="+getHeure()+" ingenieur=");
getIngenieur().afficher();System.out.println("]");	
}

@Override
public void ajouter_seance(Seance_code c)
{
	System.out.println("ajoute de seance code ");
}


/******************************************************************* setter et getter ***********************************************************************************/



}
