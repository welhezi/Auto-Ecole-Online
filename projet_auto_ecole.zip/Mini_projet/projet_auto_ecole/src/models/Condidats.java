package models;

public class Condidats {
/******************************************************************* les attributs  ****************************************************************************************/
	private int nbCondidats;
	private Condidat[] listeCondidats=new Condidat[nbCondidats];
/******************************************************************* le constructeur  **************************************************************************************/
	public Condidats(int nbCondidats, Condidat[] listeCondidats) {
		super();
		this.nbCondidats = nbCondidats;
		this.listeCondidats = new Condidat[nbCondidats];
	}
/******************************************************************* les m�thodes *****************************************************************************************/
	public void ajouter_condidat (Condidat c){
		
		boolean trouve = false;
		
		for (int i = 0; i < this.listeCondidats.length; i++) {
			if (this.listeCondidats[i] == null) {
				trouve = true;
			}
		}
		
		if (trouve) {
			
			Condidat x0 = null;
			
			for (int i = 0; i < this.listeCondidats.length; i++) {
				if (this.listeCondidats[i] != null) {
					if (this.listeCondidats[i].getNum_cin() == c.getNum_cin()) {
						x0 = this.listeCondidats[i];
					}
				}
			}
			
			if (x0 == null) {
				for (int i = 0; i < this.listeCondidats.length; i++) {
					if (this.listeCondidats[i] == null) {
						this.listeCondidats[i] = c;
						System.out.println("le condidat est ajoute aves succe");
						break;
					}
				}
			}
			else
				System.out.println("le condidat existe deja ");
		}
	}
	
	public Condidat rechercher_condidat(int num ){
		
		for (int i = 0; i < this.nbCondidats; i++) {
			if (this.listeCondidats[i] != null) {
				if (this.listeCondidats[i].getNum_cin() == num) {
					return this.listeCondidats[i];
				}
			}
		}
		
		System.out.println("le condidat n'existe pas !");
		return null;
	}
	
	public void supprimer_condidat(Condidat c)
	{ int pos=0;
		if(rechercher_condidat(c.getNum_cin())!=null)
		{	
			for (int i = 0; i < this.nbCondidats; i++)
			{
				if(listeCondidats[i].getNum_cin()==c.getNum_cin())
					pos=i;
			}
			for (int i = pos; i < this.nbCondidats-1; i++)
			{ listeCondidats[i] = listeCondidats[i+1];}
		 
		 }	
		else 
			System.out.println("Le condidat n'existe pas !");
		}
	public void afficher_condidats() 
	{	
		for(int i=0;i<this.nbCondidats;i++)
	     { System.out.println("***********************************************************************");
			System.out.println("***********************||  condidat num " +i+ " || *******************\n");
			listeCondidats[i].afficher_condidat();}
	}

	public void modifier_condidat(Condidat c,Condidat f)
	{ for(int i=0;i<this.listeCondidats.length;i++)
		{if(listeCondidats[i].equals(c)==true)
		{ if(c.equals(f)==true)
			System.out.println("on ne peut pas modifier car le condidat existe deja");
		else 
		{ c=f;System.out.println("modification de condidat termine");}
		}
		else System.out.println("pas de modification car le condidat n'existe pas ");
	}
	}
	public void modifier_num_cin(Condidat c,int num)
	{ for(int i=0;i<this.listeCondidats.length;i++)
	{if(listeCondidats[i].equals(c)==true)
		c.modifier_num_cin(c, num);
	else System.out.println("pas de modification car le condidat n'existe pas");
}
}
	public void modifier_permis(Condidat c,Vehicule p)
	{ for(int i=0;i<this.listeCondidats.length;i++)
	{if(listeCondidats[i].equals(c)==true)
		c.modifier_permis(c, p);
	else System.out.println("pas de modification car le condidat n'existe pas");
}
}
	public void modifier_seances(Condidat c,SeancesCondidat s)
	{ for(int i=0;i<this.listeCondidats.length;i++)
	{if(listeCondidats[i].equals(c)==true)
		c.modifier_seances(c, s);
	else System.out.println("pas de modification car le condidat n'existe pas");
}
}
	
/******************************************************************* setter et getter ***********************************************************************************/
	public int getNbCondidats() {
		return nbCondidats;
	}
	public void setNbCondidats(int nbCondidats) {
		this.nbCondidats = nbCondidats;
	}
	public Condidat[] getListeCondidats() {
		return listeCondidats;
	}
	public void setListeCondidats(Condidat[] listeCondidats) {
		this.listeCondidats = listeCondidats;
	}
	
	
	
	
	
	
	
	
	
	
}
