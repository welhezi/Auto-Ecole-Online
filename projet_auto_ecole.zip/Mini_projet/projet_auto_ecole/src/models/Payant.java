package models;

public interface Payant {
	public float calcul_prix(Condidat c);
}
