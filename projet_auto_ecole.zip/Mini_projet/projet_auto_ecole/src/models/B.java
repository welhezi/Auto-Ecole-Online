package models;

public class B extends Vehicule {

	public B(String voiture) {
		super(voiture);
		
	}
	
	@Override	
	public void afficher() {
		System.out.println("permis pour les voitures");
	}
}
