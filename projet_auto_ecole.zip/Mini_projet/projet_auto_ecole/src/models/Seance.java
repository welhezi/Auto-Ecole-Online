package models;

public class Seance  {

/******************************************************************* les attributs  ****************************************************************************************/
	protected int num_seance;
	protected Date date_seance;
	protected int heure;
	protected Ingenieur ingenieur;
/******************************************************************* le constructeur  **************************************************************************************/
	public Seance(int num_seance, Date date_seance, int heure, Ingenieur ingenieur) {
		this.num_seance = num_seance;
		this.date_seance = date_seance;
		this.heure = heure;
		this.ingenieur = ingenieur;
	}
	
/******************************************************************* les m�thodes *****************************************************************************************/
	public void afficher() {};
	public void ajouter_seance(Seance_conduite s) {};
	public void ajouter_seance(Seance_code s) {};
	public void ajouter_seance(Examen c) {};
	
	public void modifier_num_seance(int a) {
		this.setNum_seance(a);
	};
	
	public void modifier_date_seance(Date a) {
		this.setDate_seance(a);
	};
	
	public void modifier_heure(int a) {
		this.setHeure(a);
	};
	
	public void modifier_ingenieur(Ingenieur a) {
		this.setIngenieur(a);
	};
	
	public float calcul_prix_seance(Condidat c,Seance s) {
	float prix=0;
		if(s instanceof Seance_conduite )	
			prix=((Seance_conduite) s).calcul_prix(c);
		else if(s instanceof Seance_code ) 
			prix=((Seance_code) s).calcul_prix(c);
		else //if(s instanceof Examen )//
			prix=((Examen) s).calcul_prix(c);
	return prix;
		}
	
	
	
	
	
	
/******************************************************************* setter et getter ***********************************************************************************/
	public int getNum_seance() {
		return this.num_seance;
	}
	public void setNum_seance(int num_seance) {
		this.num_seance = num_seance;
	}
	public Date getDate_seance() {
		return this.date_seance;
	}
	public void setDate_seance(Date date_seance) {
		this.date_seance = date_seance;
	}
	public int getHeure() {
		return this.heure;
	}
	public void setHeure(int heure) {
		this.heure = heure;
	}
	public Ingenieur getIngenieur() {
		return this.ingenieur;
	}
	public void setIngenieur(Ingenieur ingenieur) {
		this.ingenieur = ingenieur;
	}


	/******************************************************************* les m�thodes *****************************************************************************************/
	



		
}





























































