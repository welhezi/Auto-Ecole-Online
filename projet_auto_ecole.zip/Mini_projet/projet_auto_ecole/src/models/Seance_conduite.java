package models;

import exceptions.NotDispoException1;
import exceptions.NotDispoException2;
import exceptions.NotDispoException3;

public class Seance_conduite extends Seance implements Payant {
/******************************************************************* les attributs  ****************************************************************************************/
private Type_permis vehicule;
/******************************************************************* le constructeur  **************************************************************************************/
public Seance_conduite(int num_seance, Date date_seance, int heure, Ingenieur ingenieur,Type_permis vehicule) throws NotDispoException1, NotDispoException2, NotDispoException3
{	super(num_seance, date_seance, heure, ingenieur);
	this.vehicule = vehicule;
}
/******************************************************************* les m�thodes *****************************************************************************************/
@Override
public float calcul_prix(Condidat c) 
{ float p=15;
if( c.getCategorie_permis() instanceof A)
	p=p+(p*4)/100;
else if(c.getCategorie_permis() instanceof B)
	p=p+(p*6)/100;
else
	p=p+(p*8)/100;
return p;

}
@Override
public void afficher() {
	System.out.println("seance_conduite [Num_seance=" + getNum_seance() + ", Date_seance=");
	getDate_seance().afficher();
	System.out.println(",heure="+getHeure()+" , ingenieur= ");
	getIngenieur().afficher();
	System.out.println(", Vehicule="); 
	getVehicule().afficher(); 
	System.out.println( "]");
}

@Override
public void ajouter_seance(Seance_conduite c)
{ System.out.println("seance_conduite est ajout� ");}

public void modifier_voiture(Type_permis v)
{if(this.getVehicule().equals(v))
	System.out.println("on ne peut pas modifier car c'est la meme voiture ");
else 
{ this.setVehicule(v);
System.out.println("modification de vehicule termine");
}
	}







/******************************************************************* setter et getter ***********************************************************************************/
public Type_permis getVehicule() {
	return vehicule;
}
public void setVehicule(Type_permis vehicule) {
	this.vehicule = vehicule;
}


}
