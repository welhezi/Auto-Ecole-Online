package models;

import java.util.Scanner;

public class Camion extends Type_permis {
/******************************************************************* les attributs  ****************************************************************************************/

/******************************************************************* le constructeur  **************************************************************************************/
public Camion(int num_immatriculation, Date date_mise_service, float kilometrage_total,float nb_km_restant_prochainEntretient/*,Seances s*/) 
{
	super(num_immatriculation, date_mise_service, kilometrage_total, nb_km_restant_prochainEntretient /*,s*/);
}

/******************************************************************* les m�thodes *****************************************************************************************/
@Override
public void afficher() {
	
	System.out.println("camion [Num_immatriculation=" + getNum_immatriculation()+ ", Date_mise_service=");
	getDate_mise_service().afficher();
    System.out.println(", Kilometrage_total="+ getKilometrage_total() + ", Nb_km_restant_prochainEntretient="+ 
	                   getNb_km_restant_prochainEntretient() +"]"); 
}

@Override
public void ajouter_vehicule(Camion c)
{ System.out.println("le camion est ajout� avec succ�");}

@Override
public void tester_filtre(){
	float r;
	if(this.getKilometrage_total()< 10000)
		{ r=10000-this.getKilometrage_total();this.setNb_km_restant_prochainEntretient(r);}
	else if(this.getKilometrage_total()>10000) {  System.out.println("attention ! vous devez faire un filtrage pour camion num = "+this.getNum_immatriculation()); }
	else System.out.println("attention ! camion de num = "+this.getNum_immatriculation()+" va depasser le kilometrage pour faire un filtrage ");
}

@Override
public void tester_vidange(){
	
	Scanner sc = new Scanner(System.in);
	System.out.println("quel est le nombre de fois de filtrage pour voiture num "+this.getNum_immatriculation()+" ? ");
	int f=sc.nextInt();
	if(f%2==0)	
	{System.out.println("attention ! il faut un vidange pour camion num = "+this.getNum_immatriculation()); 
	sc.nextFloat();}
}




}