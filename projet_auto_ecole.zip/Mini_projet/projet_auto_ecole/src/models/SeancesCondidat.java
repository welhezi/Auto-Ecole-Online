package models;

import java.util.Scanner;

public class SeancesCondidat {
/******************************************************************* les attributs  ****************************************************************************************/

private int nbSeances;
private Seance[] listeSeances=new Seance[nbSeances];
/******************************************************************* le constructeur  **************************************************************************************/
public SeancesCondidat(int nbSeances,Seance[] listeSeances) {
	super();
	this.nbSeances = nbSeances;
	this.listeSeances =new Seance[nbSeances];
}

/******************************************************************* setter et getter ***********************************************************************************/
public int getNbSeances() {
	return nbSeances;
}

public void setNbSeances(int nbSeances) {
	this.nbSeances = nbSeances;
}
public Seance[] getListeSeances() {
	return listeSeances;
}
public void setListeSeances(Seance[] listeSeances) {
	this.listeSeances = listeSeances;
}

/******************************************************************* les m�thodes *****************************************************************************************/
public void ajouter_seance (Seance c){
	
	boolean trouve = false;
	
	for (int i = 0; i < this.listeSeances.length; i++) {
		if (this.listeSeances[i] == null) {
			trouve = true;
		}
	}
	
	if (trouve) {
		
		Seance x0 = null;
		
		for (int i = 0; i < this.listeSeances.length; i++) {
			if (this.listeSeances[i] != null) {
				if (this.listeSeances[i].equals(c)) {
					x0 = this.listeSeances[i];
				}
			}
		}
		
		if (x0 == null) {
			for (int i = 0; i < this.listeSeances.length; i++) {
				if (this.listeSeances[i] == null) {
					this.listeSeances[i] = c;
					System.out.println("seance est ajoute avec succe");
					break;
				}
			}
		}
		else
			System.out.println("seance existe deja ");
	}
}

public Seance rechercher_seance(Seance s){
	
	for (int i = 0; i < this.listeSeances.length; i++) {
		if (this.listeSeances[i] != null) {
			if (this.listeSeances[i].equals(s) == true ) {
				return this.listeSeances[i];
			}
		}
	}
	System.out.println("la seance n'existe pas !");
	return null;
}

public void supprimer_seance(Seance c)
{ int pos=0;
	if(rechercher_seance(c) != null)
	{	
		for (int i = 0; i < this.listeSeances.length; i++)
		{
			if(listeSeances[i].equals(c) )
				pos=i;
		}
		for (int i = pos; i < this.getNbSeances()-1; i++)
		{ listeSeances[i] = listeSeances[i+1];}
	 
	 }	
	else 
		System.out.println("seance n'existe pas !");
	}

public void afficher_seances() 
{	
  for(int i=0;i<this.getNbSeances();i++)
     { System.out.println("-----------------------------------------------------_______ seance num " +i+ " _________--------\n");
     this.listeSeances[i].afficher();
     }
}

public void modifier_seance(Seance v1,Seance v2)
{
	for(int i=0;i<this.getNbSeances();i++)
	{
		if(v1.equals(v2)==true)
			System.out.println("seance existe");
		else {if(this.listeSeances[i].equals(v1))
			this.listeSeances[i]=v2;break;
		}
	}
}

public void modifier_listeSeances(Seance[] s)
{ this.setListeSeances(s);}

public void modifier_nbSeances(int s)
{ this.setNbSeances(s);}

public float prix_seances_a_payer(Condidat c) {
	float prix_total=0;
	for (int i = 0; i < this.listeSeances.length;i++)
			{prix_total=prix_total+c.calcul_prix_seance_condidat(c,this.listeSeances[i]);}	
	System.out.println("ce qu'il faut payer par le condidat est "+prix_total);
	return prix_total;
	}

public void prix_seances_reste_a_payer(Condidat c) {
	float reste=0;
	Scanner sc = new Scanner(System.in);
	System.out.println("merci de donner le montant que vous aller payer");
	float m=sc.nextFloat();
	reste=prix_seances_a_payer(c)-m;	
	System.out.println("le reste a payer par le condidat est "+reste); 
	//sc.nextFloat();
}

public int salaire_ingenieur(Ingenieur g)
{int travaille=0;
	for(int i=0;i<this.getNbSeances();i++)
	{
		if(this.listeSeances[i].getIngenieur().getCin()==g.getCin())
		{travaille=travaille+g.payer_ingenieur(this.listeSeances[i]);}
	 }
	return travaille;
}


public int disponibilite_ingenieur_seancesCondidat(Ingenieur g,int heure,Date d)
{int dispo=0;//disponible//
int vide=0;
for(int i=0;i<this.getNbSeances();i++)
{if(this.listeSeances[i]==null) vide=1;else vide=0;}
if(vide==1) { dispo=0;return dispo;}
else {
for(int i=0;i<this.getNbSeances();i++)
	{if( this.listeSeances[i] instanceof Seance_conduite )
		{if(((Seance_conduite)this.listeSeances[i]).getIngenieur().getCin()==g.getCin())
			{if(this.listeSeances[i].getHeure()==heure && this.listeSeances[i].getDate_seance().equals(d))	
				dispo=1;}}
	} 
return dispo;}
}

public int disponibilite_vehicule_seancesCondidat(Type_permis g,int heure,Date d)
{int dispo=0;//disponible//
int vide=0;
for(int i=0;i<this.getNbSeances();i++)
{if(this.listeSeances[i]==null) vide=1;else vide=0;}
if(vide==1) { dispo=0;return dispo;}
else {
for(int i=0;i<this.getNbSeances();i++)
	{if( this.listeSeances[i] instanceof Seance_conduite )
		{if(((Seance_conduite)this.listeSeances[i]).getVehicule().num_immatriculation==g.getNum_immatriculation())
			{if(this.listeSeances[i].getHeure()==heure && this.listeSeances[i].getDate_seance().equals(d))	
				dispo=1;}}
	} 
return dispo;}
}








}
