package models;

public class C extends Vehicule {

	public C( String camion) {
		super(camion);
		
	}
	
	@Override
	public void afficher() {
		System.out.println("permis pour les camions");
	}
}
