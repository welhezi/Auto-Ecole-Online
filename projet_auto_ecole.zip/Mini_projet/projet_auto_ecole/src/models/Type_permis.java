package models;


public abstract class Type_permis {
/******************************************************************* les attributs  ****************************************************************************************/
protected int num_immatriculation;
protected Date date_mise_service;
protected float kilometrage_total;
protected float nb_km_restant_prochainEntretient;
private Seances v;
/******************************************************************* le constructeur  **************************************************************************************/
public Type_permis(int num_immatriculation, Date date_mise_service, float kilometrage_total,float nb_km_restant_prochainEntretient) {
	super();
	this.num_immatriculation = num_immatriculation;
	this.date_mise_service = date_mise_service;
	this.kilometrage_total = kilometrage_total;
	this.nb_km_restant_prochainEntretient = nb_km_restant_prochainEntretient;
}
/******************************************************************* les m�thodes *****************************************************************************************/
public void afficher(){};
public void ajouter_vehicule(Moto c) {};
public void ajouter_vehicule(Camion c) {};
public void ajouter_vehicule(Voiture c) {};

public void modifier_num_immatriculation(int a) {
	this.setNum_immatriculation(a);
};

public void modifier_date_mise_service(Date a) {
	this.setDate_mise_service(a);
};

public void modifier_kilometrage_total(float a) {
	this.setKilometrage_total(a);
};

public void modifier_nb_km_restant_prochainEntretient(float a) {
	this.setNb_km_restant_prochainEntretient(a);
};

public void tester_filtre(){}

public void tester_vidange(){}


public boolean dispo_vehicule(Seances sss,Type_permis g,int h,Date d)
{ boolean dispo,res;
dispo=sss.disponibilite_vehicule_seances(g,h, d);
if(dispo==true) 
	res=true;
else
	res=false;
return res;
}

/******************************************************************* setter et getter ***********************************************************************************/
public int getNum_immatriculation() {
	return num_immatriculation;
}
public void setNum_immatriculation(int num_immatriculation) {
	this.num_immatriculation = num_immatriculation;
}

public Date getDate_mise_service() {
	return date_mise_service;
}

public void setDate_mise_service(Date date_mise_service) {
	this.date_mise_service = date_mise_service;
}

public float getKilometrage_total() {
	return kilometrage_total;
}

public void setKilometrage_total(float kilometrage_total) {
	this.kilometrage_total = kilometrage_total;
}

public float getNb_km_restant_prochainEntretient() {
	return nb_km_restant_prochainEntretient;
}

public void setNb_km_restant_prochainEntretient(float nb_km_restant_prochainEntretient) {
	this.nb_km_restant_prochainEntretient = nb_km_restant_prochainEntretient;
}

public Seances getV() {
	return v;
}
public void setV(Seances v) {
	this.v = v;
}

}
