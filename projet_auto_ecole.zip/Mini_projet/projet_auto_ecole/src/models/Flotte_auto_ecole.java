package models;

public class Flotte_auto_ecole {
/******************************************************************* les attributs  ****************************************************************************************/
private int nb_vehicules;
private Type_permis[] vehicules = new Type_permis[nb_vehicules];
/******************************************************************* le constructeur  **************************************************************************************/
public Flotte_auto_ecole(int nb_vehicules, Type_permis[] vehicules)
{   this.nb_vehicules = nb_vehicules;
	this.vehicules = vehicules;
}
/******************************************************************* les m�thodes *****************************************************************************************/
public void ajouter_vehicule (Type_permis c){
	
	boolean trouve = false;
	
	for (int i = 0; i < this.vehicules.length; i++) {
		if (this.vehicules[i] == null) {
			trouve = true;
		}
	}
	
	if (trouve) {
		
		Type_permis x0 = null;
		
		for (int i = 0; i < this.vehicules.length; i++) {
			if (this.vehicules[i] != null) {
				if (this.vehicules[i].equals(c)) {
					x0 = this.vehicules[i];
				}
			}
		}
		
		if (x0 == null) {
			for (int i = 0; i < this.vehicules.length; i++) {
				if (this.vehicules[i] == null) {
					this.vehicules[i] = c;
					System.out.println("vehicule est ajoute avec succe");
					break;
				}
			}
		}
		else
			System.out.println("vehicule existe deja ");
	}
}
public Type_permis rechercher_vehicule(Type_permis s){
	
	for (int i = 0; i < this.vehicules.length; i++) {
		if (this.vehicules[i] != null) {
			if (this.vehicules[i].equals(s) == true ) {
				return this.vehicules[i];
			}
		}
	}
	System.out.println("vehicule n'existe pas !");
	return null;
}

public void supprimer_vehicule(Type_permis c)
{ int pos=0;
	if(rechercher_vehicule(c) != null)
	{	
		for (int i = 0; i < this.vehicules.length; i++)
		{
			if(this.vehicules[i].equals(c) )
				pos=i;
		}
		for (int i = pos; i < this.getNb_vehicules()-1; i++)
		{ this.vehicules[i] = this.vehicules[i+1];}
	 
	 }	
	else 
		System.out.println("vehicule n'existe pas !");
	}

public void afficher_vehicules() 
{	
  for(int i=0;i<this.getNb_vehicules();i++)
     { System.out.println("-----------------------------------------------------_______ vehicule num " +i+ " _________--------\n");
     this.vehicules[i].afficher();
     }
}

public void modifier_vehicule(Type_permis v1,Type_permis v2)
{
	for(int i=0;i<this.getNb_vehicules();i++)
	{
		if(v1.equals(v2)==true)
			System.out.println("vehicule existe");
		else {if(this.vehicules[i].equals(v1))
			this.vehicules[i]=v2;break;
		}
	}
}

public void tester_etat_voitures()
{
	for(int i=0;i<this.getNb_vehicules();i++)
	{
		if(this.vehicules[i] instanceof Voiture)
			{this.vehicules[i].tester_filtre();this.vehicules[i].tester_vidange();}
		else if(this.vehicules[i] instanceof Camion)
			{this.vehicules[i].tester_filtre();this.vehicules[i].tester_vidange();}
		else {this.vehicules[i].tester_filtre();}
			
	}
	
}



/******************************************************************* setter et getter ***********************************************************************************/
public int getNb_vehicules() {
	return nb_vehicules;
}

public void setNb_vehicules(int nb_vehicules) {
	this.nb_vehicules = nb_vehicules;
}
public Type_permis[] getVehicules() {
	return vehicules;
}
public void setVehicules(Type_permis[] vehicules) {
	this.vehicules = vehicules;
}	
}
